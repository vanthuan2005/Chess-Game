package com.example.chessgame;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

/**
 * Quản lý 13 sound effect của game cờ vua.
 * Chỉ phụ trách phát âm thanh, không chứa hay thay đổi logic luật cờ.
 */
public class CheckSoundManager {

    private final SoundPool soundPool;

    private final int moveSelfSound;
    private final int moveOpponentSound;
    private final int captureSound;
    private final int checkSound;
    private final int castleSound;
    private final int promotionSound;
    private final int illegalSound;
    private final int gameStartSound;
    private final int gameEndSound;
    private final int gameDrawSound;
    private final int gameLoseSound;
    private final int tenSecondsSound;
    private final int notifySound;

    private boolean whiteTenSecondsPlayed = false;
    private boolean blackTenSecondsPlayed = false;

    public CheckSoundManager(Context context) {

        AudioAttributes attributes =
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();

        soundPool =
                new SoundPool.Builder()
                        .setMaxStreams(4)
                        .setAudioAttributes(attributes)
                        .build();

        moveSelfSound = soundPool.load(context, R.raw.move_self, 1);
        moveOpponentSound = soundPool.load(context, R.raw.move_opponent, 1);
        captureSound = soundPool.load(context, R.raw.capture, 1);
        checkSound = soundPool.load(context, R.raw.move_check, 1);
        castleSound = soundPool.load(context, R.raw.castle, 1);
        promotionSound = soundPool.load(context, R.raw.promote, 1);
        illegalSound = soundPool.load(context, R.raw.illegal, 1);
        gameStartSound = soundPool.load(context, R.raw.game_start, 1);
        gameEndSound = soundPool.load(context, R.raw.game_end, 1);
        gameDrawSound = soundPool.load(context, R.raw.game_draw, 1);
        gameLoseSound = soundPool.load(context, R.raw.game_lose, 1);
        tenSecondsSound = soundPool.load(context, R.raw.tenseconds, 1);
        notifySound = soundPool.load(context, R.raw.notify, 1);
    }

    private void play(int soundId) {
        if (soundId == 0) return;
        soundPool.play(soundId, 1f, 1f, 1, 0, 1f);
    }

    public void playMove(boolean opponent) {
        play(opponent ? moveOpponentSound : moveSelfSound);
    }

    public void playCapture() { play(captureSound); }
    public void playCheck() { play(checkSound); }
    public void playCastle() { play(castleSound); }
    public void playPromotion() { play(promotionSound); }
    public void playIllegal() { play(illegalSound); }
    public void playGameStart() { play(gameStartSound); }
    public void playGameEnd() { play(gameEndSound); }
    public void playDraw() { play(gameDrawSound); }
    public void playGameLose() { play(gameLoseSound); }
    public void playNotify() { play(notifySound); }

    public void checkTenSeconds(long whiteTimeMs, long blackTimeMs) {
        if (whiteTimeMs > 10_000) whiteTenSecondsPlayed = false;
        if (blackTimeMs > 10_000) blackTenSecondsPlayed = false;

        if (whiteTimeMs > 0 && whiteTimeMs <= 10_000 && !whiteTenSecondsPlayed) {
            whiteTenSecondsPlayed = true;
            play(tenSecondsSound);
        }

        if (blackTimeMs > 0 && blackTimeMs <= 10_000 && !blackTenSecondsPlayed) {
            blackTenSecondsPlayed = true;
            play(tenSecondsSound);
        }
    }

    public void syncClock(long whiteTimeMs, long blackTimeMs) {
        whiteTenSecondsPlayed = whiteTimeMs <= 10_000;
        blackTenSecondsPlayed = blackTimeMs <= 10_000;
    }

    public void resetClockWarnings() {
        whiteTenSecondsPlayed = false;
        blackTenSecondsPlayed = false;
    }

    public void release() {
        soundPool.release();
    }
}
