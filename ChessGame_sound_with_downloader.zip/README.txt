CACH DUNG
1. Giai nen file ZIP.
2. Chuot phai download_sounds.ps1 -> Run with PowerShell.
   Neu Windows chan script, mo PowerShell tai thu muc nay va chay:
   powershell -ExecutionPolicy Bypass -File .\download_sounds.ps1
3. Sau khi tai xong se co thu muc raw chua 13 file MP3.
4. Copy tat ca file trong raw vao:
   app\src\main\res\raw\
5. Copy ChessSoundManager.java va MainActivity.java vao package com.example.chessgame.
