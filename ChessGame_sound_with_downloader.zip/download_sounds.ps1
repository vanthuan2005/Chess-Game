﻿$ErrorActionPreference = "Stop"

$raw = Join-Path $PSScriptRoot "raw"
New-Item -ItemType Directory -Force -Path $raw | Out-Null

$files = @{
    "move_self.mp3"     = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/move-self.mp3"
    "move_opponent.mp3" = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/move-opponent.mp3"
    "capture.mp3"       = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/capture.mp3"
    "move_check.mp3"    = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/move-check.mp3"
    "castle.mp3"        = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/castle.mp3"
    "promote.mp3"       = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/promote.mp3"
    "illegal.mp3"       = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/illegal.mp3"
    "game_start.mp3"    = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/game-start.mp3"
    "game_end.mp3"      = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/game-end.mp3"
    "game_draw.mp3"     = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/game-draw.mp3"
    "game_lose.mp3"     = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/game-lose.mp3"
    "tenseconds.mp3"    = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/tenseconds.mp3"
    "notify.mp3"        = "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/notify.mp3"
}

foreach ($name in $files.Keys) {
    $dest = Join-Path $raw $name
    Write-Host "Downloading $name ..."
    Invoke-WebRequest -Uri $files[$name] -OutFile $dest
}

Write-Host ""
Write-Host "DONE - 13 sound files saved to:"
Write-Host $raw
