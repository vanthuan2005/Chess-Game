package com.example.chessgame;

public final class FenConverter {

    private FenConverter() {
    }

    public static String toFen(
            Chess chess,
            int[][] board,
            int[] whitePassant,
            int[] blackPassant) {

        StringBuilder fen =
                new StringBuilder();

        for (int row = 0;
             row < Chess.SIDE;
             row++) {

            int empty = 0;

            for (int col = 0;
                 col < Chess.SIDE;
                 col++) {

                int piece = board[row][col];

                if (piece == 0) {
                    empty++;
                    continue;
                }

                if (empty > 0) {
                    fen.append(empty);
                    empty = 0;
                }

                fen.append(
                        pieceToFen(piece));
            }

            if (empty > 0) {
                fen.append(empty);
            }

            if (row < Chess.SIDE - 1) {
                fen.append('/');
            }
        }

        fen.append(' ');
        fen.append(
                chess.getTurn() == 1
                        ? 'w'
                        : 'b');

        fen.append(' ');
        fen.append(
                castlingRights(chess));

        fen.append(' ');
        fen.append(
                enPassantSquare(
                        chess.getTurn(),
                        whitePassant,
                        blackPassant));

        // The current project does not track the 50-move counter/fullmove
        // number. They are not needed for choosing the next Stockfish move.
        fen.append(" 0 1");

        return fen.toString();
    }

    private static char pieceToFen(
            int piece) {

        switch (piece) {

            case 1:
                return 'p';
            case 2:
                return 'r';
            case 3:
                return 'n';
            case 4:
                return 'b';
            case 5:
                return 'q';
            case 6:
                return 'k';

            case 7:
                return 'P';
            case 8:
                return 'R';
            case 9:
                return 'N';
            case 10:
                return 'B';
            case 11:
                return 'Q';
            case 12:
                return 'K';

            default:
                throw new IllegalArgumentException(
                        "Unknown chess piece: "
                                + piece);
        }
    }

    private static String castlingRights(
            Chess chess) {

        StringBuilder rights =
                new StringBuilder();

        if (chess.canWhiteCastleRight()) {
            rights.append('K');
        }

        if (chess.canWhiteCastleLeft()) {
            rights.append('Q');
        }

        if (chess.canBlackCastleRight()) {
            rights.append('k');
        }

        if (chess.canBlackCastleLeft()) {
            rights.append('q');
        }

        return rights.length() == 0
                ? "-"
                : rights.toString();
    }

    private static String enPassantSquare(
            int turn,
            int[] whitePassant,
            int[] blackPassant) {

        if (turn == 2 &&
                blackPassant != null) {

            for (int col = 0;
                 col < Chess.SIDE;
                 col++) {

                if (blackPassant[col] == 1) {

                    return ""
                            + (char) ('a' + col)
                            + "3";
                }
            }
        }

        if (turn == 1 &&
                whitePassant != null) {

            for (int col = 0;
                 col < Chess.SIDE;
                 col++) {

                if (whitePassant[col] == 1) {

                    return ""
                            + (char) ('a' + col)
                            + "6";
                }
            }
        }

        return "-";
    }
}
