package com.example.chessgame;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChessBotApiClient {

    private static final String API_URL =
            "https://chess-api.com/v1";

    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    public interface Callback {
        void onSuccess(String uciMove);
        void onError(String message);
    }

    public void getBestMove(
            final String fen,
            final int depth,
            final Callback callback) {

        executor.execute(
                new Runnable() {
                    @Override
                    public void run() {

                        HttpURLConnection connection = null;

                        try {
                            URL url =
                                    new URL(API_URL);

                            connection =
                                    (HttpURLConnection)
                                            url.openConnection();

                            connection.setRequestMethod("POST");
                            connection.setConnectTimeout(10000);
                            connection.setReadTimeout(20000);
                            connection.setDoOutput(true);

                            connection.setRequestProperty(
                                    "Content-Type",
                                    "application/json; charset=UTF-8");

                            JSONObject request =
                                    new JSONObject();

                            request.put("fen", fen);
                            request.put(
                                    "depth",
                                    Math.max(
                                            1,
                                            Math.min(depth, 18)));

                            request.put("variants", 1);

                            byte[] body =
                                    request.toString()
                                            .getBytes(
                                                    StandardCharsets.UTF_8);

                            OutputStream outputStream =
                                    connection.getOutputStream();

                            outputStream.write(body);
                            outputStream.flush();
                            outputStream.close();

                            int responseCode =
                                    connection.getResponseCode();

                            InputStream inputStream =
                                    responseCode >= 200 &&
                                            responseCode < 300
                                            ? connection.getInputStream()
                                            : connection.getErrorStream();

                            String response =
                                    readAll(inputStream);

                            if (responseCode < 200 ||
                                    responseCode >= 300) {

                                callback.onError(
                                        "HTTP "
                                                + responseCode
                                                + " - "
                                                + response);

                                return;
                            }

                            JSONObject json =
                                    new JSONObject(response);

                            String move =
                                    json.optString(
                                            "move",
                                            "");

                            if (move.length() < 4) {

                                callback.onError(
                                        "API did not return a valid move");

                                return;
                            }

                            callback.onSuccess(move);

                        } catch (Exception e) {

                            callback.onError(
                                    e.getMessage() == null
                                            ? e.getClass()
                                                .getSimpleName()
                                            : e.getMessage());

                        } finally {

                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                    }
                });
    }

    private String readAll(
            InputStream inputStream)
            throws Exception {

        if (inputStream == null) {
            return "";
        }

        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                inputStream,
                                StandardCharsets.UTF_8));

        StringBuilder builder =
                new StringBuilder();

        String line;

        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }

        reader.close();

        return builder.toString();
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}
