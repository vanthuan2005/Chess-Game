package com.example.chessgame;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

public class CheckSoundManager {

    private static final int SOUND_COUNT = 13;
    private static final long ONE_MINUTE_MS = 60_000L;
    private static final long TEN_SECONDS_MS = 10_000L;

    private final SoundPool soundPool;

    private int loadedCount = 0;
    private boolean ready = false;
    private int pendingSound = 0;

    private int moveSelf;
    private int moveOpponent;
    private int capture;
    private int moveCheck;
    private int castle;
    private int promote;
    private int illegal;
    private int gameStart;
    private int gameEnd;
    private int gameLose;
    private int gameDraw;
    private int notifySound;
    private int tenSeconds;

    private boolean whiteOneMinutePlayed = false;
    private boolean blackOneMinutePlayed = false;
    private boolean whiteTenSecondsPlayed = false;
    private boolean blackTenSecondsPlayed = false;

    public CheckSoundManager(Context context) {
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(2)
                .setAudioAttributes(audioAttributes)
                .build();

        soundPool.setOnLoadCompleteListener((pool, sampleId, status) -> {
            loadedCount++;

            if (loadedCount >= SOUND_COUNT) {
                ready = true;

                if (pendingSound != 0) {
                    int sound = pendingSound;
                    pendingSound = 0;
                    play(sound);
                }
            }
        });

        loadSounds(context.getApplicationContext());
    }

    private void loadSounds(Context context) {
        moveSelf = soundPool.load(context, R.raw.move_self, 1);
        moveOpponent = soundPool.load(context, R.raw.move_opponent, 1);
        capture = soundPool.load(context, R.raw.capture, 1);
        moveCheck = soundPool.load(context, R.raw.move_check, 1);
        castle = soundPool.load(context, R.raw.castle, 1);
        promote = soundPool.load(context, R.raw.promote, 1);
        illegal = soundPool.load(context, R.raw.illegal, 1);
        gameStart = soundPool.load(context, R.raw.game_start, 1);
        gameEnd = soundPool.load(context, R.raw.game_end, 1);
        gameLose = soundPool.load(context, R.raw.game_lose, 1);
        gameDraw = soundPool.load(context, R.raw.game_draw, 1);
        notifySound = soundPool.load(context, R.raw.notify, 1);
        tenSeconds = soundPool.load(context, R.raw.tenseconds, 1);
    }

    public void playGameStart() {
        resetTimeWarnings();
        play(gameStart);
    }

    public void playIllegal() {
        play(illegal);
    }

    public void playMoveResult(
            int movingSide,
            boolean wasCapture,
            boolean wasCastle,
            boolean wasPromotion,
            boolean givesCheck) {

        if (givesCheck) {
            play(moveCheck);
            return;
        }

        if (wasPromotion) {
            play(promote);
            return;
        }

        if (wasCastle) {
            play(castle);
            return;
        }

        if (wasCapture) {
            play(capture);
            return;
        }

        if (movingSide == 1) {
            play(moveSelf);
        } else {
            play(moveOpponent);
        }
    }

    public void playGameResult(int winner) {
        // MainActivity treats winner == 1 as BLACK and winner == 2 as WHITE.
        // The bottom/"You" player is White in the current UI.
        if (winner == 1) {
            play(gameLose);
        } else {
            play(gameEnd);
        }
    }

    public void playTimeoutResult(boolean blackLost) {
        if (blackLost) {
            play(gameEnd);
        } else {
            play(gameLose);
        }
    }

    public void playDraw() {
        play(gameDraw);
    }

    public void checkTimeWarnings(long whiteTimeMs, long blackTimeMs) {
        whiteOneMinutePlayed = updateOneMinuteWarning(
                whiteTimeMs,
                whiteOneMinutePlayed);

        blackOneMinutePlayed = updateOneMinuteWarning(
                blackTimeMs,
                blackOneMinutePlayed);

        whiteTenSecondsPlayed = updateTenSecondWarning(
                whiteTimeMs,
                whiteTenSecondsPlayed);

        blackTenSecondsPlayed = updateTenSecondWarning(
                blackTimeMs,
                blackTenSecondsPlayed);
    }

    private boolean updateOneMinuteWarning(long timeMs, boolean alreadyPlayed) {
        if (timeMs > ONE_MINUTE_MS) {
            return false;
        }

        if (timeMs > TEN_SECONDS_MS && !alreadyPlayed) {
            play(notifySound);
            return true;
        }

        return alreadyPlayed;
    }

    private boolean updateTenSecondWarning(long timeMs, boolean alreadyPlayed) {
        if (timeMs > TEN_SECONDS_MS) {
            return false;
        }

        if (timeMs > 0 && !alreadyPlayed) {
            play(tenSeconds);
            return true;
        }

        return alreadyPlayed;
    }

    public void resetTimeWarnings() {
        whiteOneMinutePlayed = false;
        blackOneMinutePlayed = false;
        whiteTenSecondsPlayed = false;
        blackTenSecondsPlayed = false;
    }

    public void release() {
        pendingSound = 0;
        ready = false;
        soundPool.release();
    }

    private void play(int soundId) {
        if (soundId == 0) {
            return;
        }

        if (!ready) {
            pendingSound = soundId;
            return;
        }

        soundPool.play(soundId, 1f, 1f, 1, 0, 1f);
    }
}
